function toogleMenu() {
    var sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('active')
}